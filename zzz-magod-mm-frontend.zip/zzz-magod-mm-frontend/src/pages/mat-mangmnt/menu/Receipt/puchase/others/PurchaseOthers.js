import React from "react";

function PurchaseOthers() {
  return <div>PurchaseOthers</div>;
}

export default PurchaseOthers;
