import React from "react";
import NewSheetsUnits from "../../NewSheetsUnits";

function PurOtherNew() {
  return <NewSheetsUnits type="sheets" type2="purchase" />;
}

export default PurOtherNew;
