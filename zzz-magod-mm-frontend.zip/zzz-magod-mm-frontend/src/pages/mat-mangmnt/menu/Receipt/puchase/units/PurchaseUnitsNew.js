import React from "react";
import NewSheetsUnits from "../../NewSheetsUnits";

function PurchaseUnitsNew() {
  return <NewSheetsUnits type="units" type2="purchase" />;
}

export default PurchaseUnitsNew;
