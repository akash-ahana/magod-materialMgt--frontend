import React from "react";
import NewSheetsUnits from "../../NewSheetsUnits";

function PurchaseGasNew() {
  return <NewSheetsUnits type="gas" />;
}

export default PurchaseGasNew;
