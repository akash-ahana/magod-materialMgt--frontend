import React from "react";
import NewSheetsUnits from "../../NewSheetsUnits";

function UnitsNew() {
  return <NewSheetsUnits type="units" />;
}

export default UnitsNew;
