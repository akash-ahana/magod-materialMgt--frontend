import React from "react";
import NewSheetsUnits from "../../NewSheetsUnits";

function SheetsNew() {
  return <NewSheetsUnits type="sheets" />;
}

export default SheetsNew;
