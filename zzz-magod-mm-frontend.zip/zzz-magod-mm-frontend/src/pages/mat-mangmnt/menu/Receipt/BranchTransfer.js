import React from 'react'

function BranchTransfer() {
  return (
    <div>BranchTransfer</div>
  )
}

export default BranchTransfer