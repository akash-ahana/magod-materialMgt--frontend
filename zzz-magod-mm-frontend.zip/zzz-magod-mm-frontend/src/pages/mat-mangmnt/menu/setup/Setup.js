import React from 'react'

function Setup() {
  return (
    <div>Server</div>
  )
}

export default Setup