import React from "react";
import LocationModel from "./LocationModel";

function ReturnAsScrap() {
  return (
    <div>
      <LocationModel />
    </div>
  );
}

export default ReturnAsScrap;
