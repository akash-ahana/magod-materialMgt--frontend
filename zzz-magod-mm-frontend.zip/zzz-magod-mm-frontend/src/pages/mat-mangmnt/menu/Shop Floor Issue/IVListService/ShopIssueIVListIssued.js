import React from "react";
import ShopIssueIVList from "./ShopIssueIVList";

function ShopIssueIVListIssued() {
  return <ShopIssueIVList type="issued" />;
}

export default ShopIssueIVListIssued;
