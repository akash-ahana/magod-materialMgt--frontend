import React from "react";
import ShopIssueIVList from "./ShopIssueIVList";

function ShopIssueIVListClosed() {
  return <ShopIssueIVList type="closed" />;
}

export default ShopIssueIVListClosed;
