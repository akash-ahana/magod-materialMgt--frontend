import React from "react";
import IVListProfileCutting from "./IVListProfileCutting";

function IVListProfileCuttingClosed() {
  return <IVListProfileCutting type="closed" />;
}

export default IVListProfileCuttingClosed;
