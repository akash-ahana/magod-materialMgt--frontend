import React from "react";
import IVListProfileCutting from "./IVListProfileCutting";

function IVListProfileCuttingCurrent() {
  return <IVListProfileCutting type="current" />;
}

export default IVListProfileCuttingCurrent;
