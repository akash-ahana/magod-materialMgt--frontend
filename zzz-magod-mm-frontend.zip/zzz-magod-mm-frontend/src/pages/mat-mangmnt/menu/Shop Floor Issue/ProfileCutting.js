import React from "react";
import ShopFloorMaterialAllotment from "./Service/PartsComponents/ShopFloorMaterialAllotment";

function ProfileCutting() {
  return (
    <div>
      <ShopFloorMaterialAllotment type="Profile" hasbom="0" formtype="Others" />
    </div>
  );
}

export default ProfileCutting;
