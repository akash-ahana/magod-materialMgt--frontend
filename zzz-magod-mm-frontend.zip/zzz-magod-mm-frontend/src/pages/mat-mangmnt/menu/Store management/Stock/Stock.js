import React from 'react'

function Stock() {
  return (
    <div>Stock</div>
  )
}

export default Stock