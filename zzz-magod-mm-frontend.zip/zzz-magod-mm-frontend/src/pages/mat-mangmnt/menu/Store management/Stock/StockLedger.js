import React from 'react'

function StockLedger() {
  return (
    <div>StockLedger</div>
  )
}

export default StockLedger