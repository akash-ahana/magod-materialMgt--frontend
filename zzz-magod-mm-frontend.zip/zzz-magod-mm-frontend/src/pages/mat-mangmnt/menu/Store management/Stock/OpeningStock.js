import React from "react";

function OpeningStock() {
  return <div>OpeningStock</div>;
}

export default OpeningStock;
