import React from 'react'

function StoreManagement() {
  return (
    <div>StoreManagement</div>
  )
}

export default StoreManagement