import React from "react";
import SheetResizeForm from "./SheetResizeForm";

function ResizeSheets() {
  return (
    <div>
      <SheetResizeForm />
    </div>
  );
}

export default ResizeSheets;
