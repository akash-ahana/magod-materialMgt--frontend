import React from "react";
import LocationStockReport from "./LocationStockReport";

function LocationStock() {
  return (
    <div>
      <LocationStockReport/>
    </div>
  );
}

export default LocationStock;
