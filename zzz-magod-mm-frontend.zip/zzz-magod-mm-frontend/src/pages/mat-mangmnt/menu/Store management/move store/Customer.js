import React from "react";
import MaterialMoverForm from "./MaterialMoverForm";

function Customer() {
  return (
    <div>
      <MaterialMoverForm type="customer" />
    </div>
  );
}

export default Customer;
