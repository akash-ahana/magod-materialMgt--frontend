import React from 'react'

function MoveStore() {
  return (
    <div>MoveStore</div>
  )
}

export default MoveStore