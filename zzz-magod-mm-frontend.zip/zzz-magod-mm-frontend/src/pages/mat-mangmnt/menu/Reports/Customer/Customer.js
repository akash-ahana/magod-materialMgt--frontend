import React from "react";
import MaterialStockList from "./Components/MaterialStockList";

function Customer() {
  return <div></div>;
}

export default Customer;
