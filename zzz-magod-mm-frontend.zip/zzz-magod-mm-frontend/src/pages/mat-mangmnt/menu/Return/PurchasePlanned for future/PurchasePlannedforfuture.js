import React from "react";

function PurchasePlannedforfuture() {
  return (
    <>
      <div>PurchasePlannedforfuture</div>
      <div>(Its planned for next realese of the software)</div>
    </>
  );
}

export default PurchasePlannedforfuture;
