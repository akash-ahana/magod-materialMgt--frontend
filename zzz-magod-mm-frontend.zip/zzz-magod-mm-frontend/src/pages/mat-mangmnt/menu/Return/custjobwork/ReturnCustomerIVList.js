import React from "react";
import ReturnListing from "./ReturnListing";

function ReturnCustomerIVList() {
  return <ReturnListing type="customerIVList" />;
}

export default ReturnCustomerIVList;
