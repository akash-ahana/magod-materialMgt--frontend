import React from "react";

function CustomerJobWork() {
  return <div>asdfghjkl</div>;
}

export default CustomerJobWork;
