import React from "react";
import ReturnListing from "./ReturnListing";

function ReturnCancelled() {
  return <ReturnListing type="returnCancelled" />;
}

export default ReturnCancelled;
