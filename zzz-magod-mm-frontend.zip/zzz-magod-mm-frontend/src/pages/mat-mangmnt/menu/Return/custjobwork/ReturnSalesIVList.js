import React from "react";
import ReturnListing from "./ReturnListing";

function ReturnSalesIVList() {
  return <ReturnListing type="returnSaleListing" />;
}

export default ReturnSalesIVList;
