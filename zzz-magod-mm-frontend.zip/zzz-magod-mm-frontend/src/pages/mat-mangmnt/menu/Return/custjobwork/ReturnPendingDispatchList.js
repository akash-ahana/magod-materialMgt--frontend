import React from "react";
import ReturnListing from "./ReturnListing";

function ReturnPendingDispatchList() {
  return <ReturnListing type="pendingDispatch" />;
}

export default ReturnPendingDispatchList;
