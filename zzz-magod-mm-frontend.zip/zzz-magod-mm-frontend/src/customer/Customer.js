import React from "react";

const Customer = () => {
  return (
    <div>
      <h1>Customer</h1>
    </div>
  );
};

export default Customer;
