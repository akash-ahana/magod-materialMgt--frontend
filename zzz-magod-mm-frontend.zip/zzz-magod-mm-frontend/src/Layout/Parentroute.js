import React from 'react'
import { Outlet } from 'react-router-dom'

function Parentroute() {
  return <Outlet/>
}

export default Parentroute