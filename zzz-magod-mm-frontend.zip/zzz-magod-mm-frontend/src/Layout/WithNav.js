import React from 'react'
import SharedLayout from './SharedLayout'

function WithNav() {
  return  <SharedLayout/>
}

export default WithNav